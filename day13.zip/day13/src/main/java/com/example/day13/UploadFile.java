package com.example.day13;

import android.text.TextUtils;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;

public class UploadFile implements Runnable {

    String filePath;
    String uploadurl;

    public UploadFile(String filePath, String uploadurl) {
        this.filePath = filePath;
        this.uploadurl = uploadurl;
    }

    @Override
    public void run() {

        // do something --上传

        HashMap<String,String>  map = new HashMap<>();
        map.put("key","imgs");
        File file = new File(filePath);
        try {
           String result= HttpUtils.uploadForm(map,"file",file,file.getName(),uploadurl);

           if (!TextUtils.isEmpty(result)&&uploadListener!=null){

               uploadListener.uploadSuccess(result);
           }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    interface UploadListener{
        void uploadSuccess(String result);
    }

    UploadListener uploadListener;

    public void setUploadListener(UploadListener uploadListener){
        this.uploadListener = uploadListener;
    }
}
